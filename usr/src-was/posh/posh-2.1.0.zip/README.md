# posh

## AUTHOR

Bill Stewart - bstewart at iname dot com

## LICENSE

**posh** is covered by the GNU Public License (GPL). See the file `LICENSE` for details.

## SYNOPSIS

Runs Windows PowerShell or PowerShell core using `winpty.exe`. This is used by the CygSSH package when remoting to a Windows server.

## USAGE

**posh** [**-c**] [**--** [_parameters_]]

Use **-c** to run PowerShell Core rather than Windows PowerShell.

If you need to specify any other command-line parameters to PowerShell, put **--** at the end of the command line and any parameters after that; e.g.:

`posh -- -NoProfile`

The above would run the following:

`powershell.exe -NoProfile`

using `winpty.exe`.
