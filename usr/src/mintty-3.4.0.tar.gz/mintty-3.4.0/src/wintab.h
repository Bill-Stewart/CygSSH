extern bool win_tabbar_visible();
extern void win_open_tabbar();
extern void win_update_tabbar();
extern void win_close_tabbar();

