runposh - Copyright (C) 2020 by Bill Stewart (bstewart at iname.com)

This is free software and comes with ABSOLUTELY NO WARRANTY.

SYNOPSIS

Runs a PowerShell script or opens an interactive PowerShell session.

USAGE

runposh [parameters] [scriptfile [-- script params]]

Omit a script filename to open an interactive PowerShell session. Parameter
names are case-sensitive. Long parameter names can be specified partially if
enough of the parameter name is specified to prevent ambiguity.

GENERAL PARAMETERS

The following parameters apply whether running a script or not:

Long Name                  Short Name   Description
-------------------------- ------------ ---------------------------------------
--bypassexecutionpolicy    -b           Bypass PowerShell execution policy
--configurationname=name                Run PS in a configuration endpoint
--core[=path]              -c [path]    Use PS Core (path = path to pwsh.exe)
--elevate                  -e           Request to run as administrator
--help                     -h           Display usage information
--mta                                   Use multithreaded apartment
--outputformat=format                   Specifies output format (Text or XML)
--quiet                    -q           Suppress error messages
--windowstyle=style        -W style     Specifies window style
--windowtitle[=text]       -t [text]    Specifies a window title
--workingdirectory=path    -d path      Specifies a working directory

* If a parameter's argument contains spaces, enclose it in " characters; e.g.:
  --windowtitle="Sample window title"

* --mta parameter is ignored if using --core (-c) as it applies to Windows
  PowerShell only

* --outputputformat parameter's argument must be Text or XML (argument is not
  case-sensitive)

* --windowstyle (-W) parameter's argument must be one of the following: Normal,
  Minimized, Maximized, Hidden, NormalNotActive, or MinimizedNotActive
  (argument is not case-sensitive)

* --workingdirectory (-d) parameter is ignored if using --elevate (-e)

PARAMETERS IF RUNNING A SCRIPT

The following parameters apply only when running a script:

Long Name          Short Name   Description
------------------ ------------ --------------------------------------------
--loadprofile                   Load PS profile(s) before running script
--noexit                        Keep PS window open after running script
--noninteractive                Run the script non-interactively
--pause            -p           Pause window after script completes
--wait             -w           Wait for exit and return process exit code
scriptfile                      Specifies name of script file to run
-- script params                Put script parameters (if any) after --

* If the script file's path or filename contains spaces, enclose it in "
  characters; e.g.: "C:\My Scripts\script.ps1"

* --pause (-p) and --wait (-w) are ignored if --noexit is specified

PARAMETERS IF NOT RUNNING A SCRIPT

The following parameter applies only when not running a script:

Name          Description
------------- -----------------------------------
--noprofile   Do not load PowerShell profile(s)

EXIT CODES

* Exit code will be 0 for success, non-zero for error

* If --wait (-w) specified, exit code is PowerShell process exit code

POWERSHELL CORE

By default, Windows PowerShell is used rather than PowerShell Core. You can run
PowerShell Core instead by specifying the --core (-c) parameter. If you have
more than one version of PowerShell Core installed, you can run a specific
version by specifying the path and filename of pwsh.exe as the argument; e.g.:
--core="C:\Program Files\PowerShell\6\pwsh.exe"

32-BIT AND 64-BIT

It's recommended to run the 64-bit (x64) version of runposh on 64-bit operating
systems unless there's a specific need on that platform to run a 32-bit (x86)
version of PowerShell. Running the 32-bit (x86) version of runposh on a 64-bit
operating system will, of course, run the 32-bit version of Windows PowerShell
or PowerShell Core (if the 32-bit version of PowerShell Core is installed).

EXECUTION POLICY

It's important to understand that the PowerShell execution policy is an
administrator safety feature; it is not a security boundary. (Think seatbelt,
not door lock.) Another way to say this is that PowerShell does not increase a
user's privileges just because the user can run scripts.

The purpose of the PowerShell execution policy is to assist administrators that
want to safeguard against accidentally running unsigned scripts. Execution
policy should not be (ab)used to try to prevent users from running scripts if
necessary.

This view is validated by Bruce Payette, head designer of the PowerShell
language at Microsoft (see https://stackoverflow.com/questions/49772982/):

  ExecutionPolicy is not a security boundary. As someone opined elsewhere in a
  comment, it is a safety feature. Think seat belt not door lock. But seat
  belts mitigate risk so it's better to use them than not. ExecutionPolicy
  mitigates the risk of unintentionally running malicious code. The generally
  recommended minimum policy is RemoteSigned.

(The "someone" Bruce mentioned is this author)

Some IT and/or security administrators are under the mistaken impression that
(ab)using the PowerShell execution policy to prevent scripts from running
somehow increases security. This mistaken idea prevents users from doing
legitimate work.

In general, this author would recommend working within the organization to
educate IT and security administrators to explain the purpose of the PowerShell
execution policy and why it does not increase security to prevent scripts from
running.

In cases where this is not possible or is infeasible, runposh provides the
--bypassexecutionpolicy (-b) parameter. When you use this parameter, runposh
runs the following function when it starts the PowerShell session:

  function Disable-ExecutionPolicy {
    ($c = $ExecutionContext.GetType().GetField("_context",
    "NonPublic,Instance").GetValue($ExecutionContext)).GetType(
    ).GetField("%1","NonPublic,Instance").SetValue($c,
    (New-Object Management.Automation.AuthorizationManager `
      "Microsoft.PowerShell"))
  }

The %1 token in this function is the authorization manager's name in Windows
PowerShell (_authorizationManager) or PowerShell Core
(<AuthorizationManager>k__BackingField).

EXAMPLES

* Run a PowerShell script using Windows PowerShell and pause window after
  script completes:

    runposh --pause "C:\Script Files\Test Script.ps1"

  --pause can be abbreviated as -p.

* Start an interactive PowerShell Core session:

    runposh --core

* Run a PowerShell script using PowerShell Core, passing parameters to the
  script:

    runposh -c "C:\Script Files\Core Script.ps1" -- -Param1 "Script Param"

  The -- parameter specifies that everything after it is parameters for the
  script.

* Start an interactive Windows PowerShell session that runs the profile script,
  bypassing execution policy (all on one line):

    runposh -b --noexit C:\Users\username\Documents\WindowsPowerShell\
      Microsoft.PowerShell_profile.ps1

  This can be useful in the case where the execution policy is being (ab)used
  to prevent scripts from running and you want to start an interactive
  PowerShell session that starts the profile script at startup.

VERSION HISTORY

* 1.3 (2020-07-15)

  * Build using FPC 3.2.0.

* 1.2 (2020-04-14)

  * Disable-ExecutionPolicy function available in all PowerShell sessions, but
    only run automatically if --bypassexecutionpolicy (-b) specified.

  * Added a number of short parameters (-e, -p, etc.).

  * Added --noexit parameter.

* 1.1 (2020-03-05)

  * Redesigned parameter parsing code to make it easier to read and more
    extensible.

* 1.0 (2020-02-24)

  * Initial version.
