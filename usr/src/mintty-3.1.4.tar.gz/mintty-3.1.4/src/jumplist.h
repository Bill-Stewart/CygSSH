extern void * init_jumplist();
extern HRESULT setup_jumplist(wstring appid, int n, wstring titles[], wstring cmds[], wstring icons[], int ii[]);

