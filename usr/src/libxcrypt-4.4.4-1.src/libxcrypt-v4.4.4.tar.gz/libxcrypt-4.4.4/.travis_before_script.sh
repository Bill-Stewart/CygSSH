#!/bin/bash
set -e

./bootstrap
