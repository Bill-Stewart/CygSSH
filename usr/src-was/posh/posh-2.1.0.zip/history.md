# posh Version History

* 2.1.0 (2021-08-04)

  * Use Unicode strings.
  * Compile using FPC 3.2.2.
