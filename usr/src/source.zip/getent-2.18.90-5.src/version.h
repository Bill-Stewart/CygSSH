/* This file just defines the current version number of libc.  */

#define RELEASE "development"
#define VERSION "2.18.90"
