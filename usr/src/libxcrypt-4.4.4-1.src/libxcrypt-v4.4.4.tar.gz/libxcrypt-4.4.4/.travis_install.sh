#!/bin/bash
set -e

pip install --user codecov
