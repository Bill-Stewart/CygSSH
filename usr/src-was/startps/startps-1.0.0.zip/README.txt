startps

AUTHOR

Bill Stewart - bstewart at iname dot com

LICENSE

startps is covered by the GNU Public License (GPL). See the file LICENSE for
details.

DOWNLOAD

https://github.com/Bill-Stewart/startps/releases/

SYNOPSIS

Runs a PowerShell script or opens an interactive PowerShell session.

USAGE

startps [parameters] [scriptfile [-- script params]]
or: startps [parameters] --interactive

Parameter names are case-sensitive. Long parameter names can be specified
partially if enough of the parameter name is specified to prevent ambiguity.

GENERAL PARAMETERS

The following parameters apply whether running a script or not:

Long Name                    Short Name   Description
---------------------------- ------------ ---------------------------------------
--configurationname=name                  Run PS in a configuration endpoint
--consolefilename=filename                Load a PS console file
--core[=path]                -c [path]    Use PS Core (path = path to pwsh.exe)
--disableexecutionpolicy     -D           Disable PS execution policy
--elevate                    -e           Request to run as administrator
--help                       -h           Display usage information
--mta                                     Use multi-threaded apartment
--outputformat=format                     Specify output format (Text or XML)
--quiet                      -q           Suppress error messages
--sta                                     Use single-threaded apartment
--version=version                         Run PS using specified version
--windowstyle=style          -W style     Specify a window style
--windowtitle[=text]         -t [text]    Specify a window title
--workingdirectory=path      -d path      Specify a working directory

Notes:

* If a parameter's argument contains spaces, enclose it in " characters. For
  example:

  * --core="C:\Program Files\PowerShell\7\pwsh.exe"
  * --windowtitle="Sample window title"
  * --workingdirectory="C:\Program Files"

* --outputputformat parameter's argument must be Text or XML (argument is not
  case-sensitive)

* --windowstyle (-W) parameter's argument must be one of the following: Normal,
  Minimized, Maximized, Hidden, NormalNotActive, or MinimizedNotActive
  (argument is not case-sensitive)

* --workingdirectory (-d) parameter is ignored if --elevate (-e) is specified

* The --mta and --sta parameters are mutually exclusive

* The --consolefilename and --version parameters are specific to Windows
  PowerShell and are ignored if running PowerShell Core

* In practice, the --version parameter is only used to start the Windows
  PowerShell 2.0 engine (i.e., --version 2; not recommended)

PARAMETERS IF RUNNING A SCRIPT

The following parameters apply only when running a script:

Long Name          Short Name   Description
------------------ ------------ --------------------------------------------
--loadprofile                   Load PS profile(s) before running script
--noexit                        Keep PS window open after running script
--noninteractive   -n           Run the script non-interactively
--pause            -p           Pause window after script completes
--wait             -w           Wait for exit and return process exit code
scriptfile                      Path/filename of script to run
-- script params                Put script parameters (if any) after --

Notes:

* If the script file's path or filename contains spaces, enclose it in "
  characters; e.g.: "C:\My Scripts\script.ps1"

* --pause (-p) and --wait (-w) are ignored if --noexit is specified

PARAMETERS IF RUNNING INTERACTIVELY

The following parameters apply only when running PS interactively:

Long Name       Short Name   Description
--------------- ------------ --------------------------------------
--interactive   -i           Open interactive PS window
--logo                       Show the copyright banner at startup
--noprofile                  Do not load PS profile(s)

EXIT CODES

* Exit code will be 0 for success, non-zero for error

* If --wait (-w) specified, exit code will be PowerShell process exit code

POWERSHELL CORE

By default, Windows PowerShell is used rather than PowerShell Core. You can run
PowerShell Core instead by specifying the --core (-c) parameter. If you have
more than one version of PowerShell Core installed, you can run a specific
version by specifying the path and filename of pwsh.exe as the argument; e.g.:
--core="C:\Program Files\PowerShell\7\pwsh.exe".

32-BIT VS. 64-BIT

It's recommended to run the 64-bit (x64) version of startps on 64-bit operating
systems unless there's a specific need on that platform to run a 32-bit (x86)
version of PowerShell. Running the 32-bit (x86) version of startps on a 64-bit
operating system will, of course, run the 32-bit version of Windows PowerShell
or PowerShell Core (if the 32-bit version of PowerShell Core is installed).

EXAMPLES

* Run a PowerShell script using Windows PowerShell and pause window after
  script completes:

    startps --pause "C:\Script Files\Test Script.ps1"

  --pause can be abbreviated as -p.

* Start an interactive PowerShell Core session:

    startps --core --interactive

* Run a PowerShell script using PowerShell Core, passing parameters to the
  script:

    startps -c "C:\Script Files\Core Script.ps1" -- -Param1 "Script Param"

  The -- parameter specifies that everything after it is parameters for the
  script.
